GREED PIT — Browser Game Package

UPLOAD:
Upload every file in this folder to any static website host.

START FILE:
index.html

FILES:
- index.html — the entire game
- manifest.webmanifest — installable web-app metadata
- sw.js — basic offline caching after the first successful hosted load

The game can still run directly as index.html, but service-worker/offline install features require normal http/https hosting.

On iPhone, once hosted, open the URL in Safari and use Share -> Add to Home Screen for an app-like launch.
